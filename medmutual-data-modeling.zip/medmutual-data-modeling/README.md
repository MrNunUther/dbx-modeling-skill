# medmutual-data-modeling

An internal Medical Mutual project: a portable, domain-neutral enterprise modeling
skill for agent hosts that support standard agent skills. Databricks-specific
references are optional platform guidance; this is not a Databricks product. Start
with [SKILL.md](SKILL.md). Version: **0.1.0**.

## Installation and invocation

Copy this entire folder into an agent's supported skill location, keeping the
folder name `medmutual-data-modeling`. For example, a project supporting Agent Skills
can use `.agents/skills/medmutual-data-modeling/` or its documented host-specific
equivalent. Do not copy only the entrypoint: its relative references are required.
Host discovery paths vary; this package does not install itself or modify host
configuration. If auto-discovery is unavailable, explicitly load
[SKILL.md](SKILL.md) and the references it selects.

## First-time path

Start with [SKILL.md](SKILL.md), then follow only the matching path:

| Goal | First artifact/reference | Next step |
|---|---|---|
| Create a model | [Model brief](templates/model-brief.json) and [workflow](references/modeling-workflow.md) | Fix scope, requirements, ownership, and grains before attributes and relationships |
| Review an existing model | [Quality and validation](references/quality-and-validation.md) | Preserve the input, inspect shape, and report evidence before proposing a change |
| Evolve a model | [Evolution workflow](references/model-evolution.md) and [proposal template](templates/model-change-proposal.json) | Trace impacts and open decisions; hand implementation to its owner |
| Design metrics | [Metric design](references/enterprise-objects.md#metric-design) | Define grain, measures, time, and joins before asking a platform specialist for implementation |
| Verify live state | [Authorization protocol](references/authorized-live-validation.md) | Obtain explicit scope/consent and use an authorized execution path; this package has no connector |

The [thin teaching suite](examples/health-insurance/README.md) is the shortest
artifact walkthrough. The [enterprise-depth suite](examples/health-insurance-enterprise/README.md)
shows deeper cross-domain coverage; its assumptions are illustrative, not
industry requirements.

Example requests:

- "Use medmutual-data-modeling to model procurement from requisition through payment.
  Preserve the named purchasing and finance domains; no workspace execution."
- "Review this model for grain, FK semantics, snapshot preservation, and
  requirement coverage. Provide evidence-bearing findings; do not modify input."
- "Design a two-domain reduced core; keep my product names and do not expand it
  to meet division ratios."

## What's included

- [Task-oriented references](references/modeling-workflow.md), portable
  [instructions](rules/instructions.md), and [canonical rules](rules/modeling-rules.csv).
- [Model contract](templates/model.schema.json), [brief](templates/model-brief.json),
  [conventions](templates/conventions.json), and validation report templates.
- A corrected [health-insurance teaching suite](examples/health-insurance/README.md)
  with matched JSON, SQL, DBML, and traceability. It is deliberately thin.
- A separate [cross-domain enterprise-depth suite](examples/health-insurance-enterprise/README.md)
  to show how a bounded process can be modeled at depth without turning breadth
  ratios into quotas.
- A portable [model-evolution proposal template](templates/model-change-proposal.json)
  and [worked example](examples/model-evolution/README.md). No diff engine,
  migration DDL generator, or executor is included.
- [Enterprise-depth](references/enterprise-depth.md) defaults: per-class coverage
  checklists and metadata depth, with a finished
  [depth example](examples/enterprise-depth/README.md). A bounded scope limits
  breadth, not depth.
- Offline checks using maintained JSON Schema validation, standard-library
  tests, and deterministic example rendering. No platform credentials required.
- An [authorized-live-validation protocol](references/authorized-live-validation.md),
  not a live executor.
- Default shape guidance from a corpus-derived
  [shape envelope](references/shape-topology.md), covering product forms, an
  anti-pattern catalog, and model topology. It comes with
  `scripts/shape_profile.py`:
  - `advise` reviews any table, model, or bounded DDL, infers undeclared classes
    with a corpus-trained classifier (79% held-out accuracy), and suggests
    remedies;
  - `check` scores models on topology, product shape, and a composite calibrated
    on the agent corpus (median about 88), after discounting boilerplate columns
    and stock sentences;
  - `targets` sizes full MVM/ECM scopes;
  - `profile` and `build-envelope` support regeneration.

  The envelope is validated by leave-one-industry-out. See the
  [anti-pattern remodel](examples/anti-patterns/README.md) example.

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python scripts/validate_skill.py --root .
.venv/bin/python -m unittest discover -s tests -p 'test_*.py'
.venv/bin/python scripts/render_example.py --root . --check
.venv/bin/python scripts/render_example.py --root . --example health-insurance-enterprise --check
.venv/bin/python scripts/validate_skill.py --root . --example health-insurance-enterprise
```

The renderer accepts only the two documented canonical examples and performs
no SQL execution. After approved canonical-example changes, regenerate the
teaching suite with `.venv/bin/python scripts/render_example.py --root . --write`
or the depth suite with
`.venv/bin/python scripts/render_example.py --root . --example health-insurance-enterprise --write`.
Refresh the teaching static report
with `.venv/bin/python scripts/validate_skill.py --root . --write-report`. Neither command
is a general-purpose legacy model importer. To refresh the depth suite's report
and traceability statuses, add `--example health-insurance-enterprise --write-report`.

## Evidence and limitations

Offline structural checks do not prove business correctness, runtime syntax,
access control, physical parity, or data integrity. The
[static report](examples/health-insurance/validation/static-report.json) explicitly
marks live checks `not_run`. No live validation, deployment, Git operations,
synthetic data generation, or autonomous repair is included.

The six teaching requirements include five statically checked requirements and
one manual semantics review. The denominator retains the manual item; the static
report is not an enterprise-readiness score.

Editorial workflow walkthroughs (not agent-host runtime evaluations):

| Request | Expected skill path |
|---|---|
| Minimal new enterprise core | Brief -> ownership/grain -> explicit keys -> matched artifacts -> evidence-level report |
| Existing-model review | Preserve input -> compare declared/observed facts -> report findings -> bounded change proposal |
| Protected names and tiny scope | Honor names/counts -> surface mapping conflicts -> no quota-driven expansion |

The test suite exercises structural cases, both example contracts/artifact sets,
the review-only evolution template, and the protected/tiny-scope boundary.
Host-specific discovery and autonomous agent adherence remain future evaluations.

See [source assessment](references/source-assessment.md) for source inventory,
conflicts, fingerprints, and rule/instruction dispositions. Source material is
reconciled and re-authored, not an unmodified upstream distribution.

## Maturation

After separate scope/authorization: read-only SDK verification, scratch
installation, additional industries/profiles,
legacy importers, workbook/ontology exports, host-runtime evaluations, and CI.
Do not treat this roadmap as implemented capability.
