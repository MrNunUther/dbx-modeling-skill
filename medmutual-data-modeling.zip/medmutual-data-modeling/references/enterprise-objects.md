# Enterprise objects and canonical contract

Modification notice: original synthesis informed by the source inventory.

## Hierarchy and semantics

Business/model -> division classification -> domain -> subdomain -> product ->
attribute/key. Relationships connect products; analytical projections sit outside
the normalized core. Division and subdomain are semantic labels, not necessarily
catalog/schema boundaries.

Domain ownership is based on business responsibility and stewardship, not a
universal department blacklist. A valid lookup may have only a few columns.
Do not pad attributes, merge unrelated grains, or create corporate domains merely
to fill a quota. Full/reduced scope is explicit; legacy ECM/MVM names are ambiguous.

Each product declares purpose, grain, classification, role, steward, a PK column
tuple, and business uniqueness tuples. An association owns a real relationship,
not an analytical correlation. A transaction line and its header have distinct
identities and lifecycles.

## Contract 1.0.0

[model.schema.json](../templates/model.schema.json) documents the complete
bounded MVP shape. The offline validator uses `jsonschema` for shape validation
and explicit checks for model semantics. Additional undocumented fields are
rejected rather than accepted as silently ignored instructions.

| Field | Meaning |
|---|---|
| `contract_version` | Shape version, independent of skill/model/source versions |
| `model_version` | Immutable model snapshot version |
| `business` | Name, industry, jurisdiction, process list |
| `profile`, `scope`, `conventions` | Applied design policy and configuration |
| `provenance` | Source references, adaptation method, no secrets |
| `domains` | Name, physical schema, division, owner, descriptions/subdomains/products |
| `products` | Physical/logical identity, classification, role, grain, keys, attributes |
| `attributes` | Type/nullability, monetary/snapshot semantics, glossary, description, classification, references, constraints, tags |
| `relationships` | Endpoint tuples, cardinality, role, optionality, phase, justification |
| `metric_views` | Single-source MVP projections with declared column dependencies; multi-source proposals need the conceptual review below and a supported implementation contract |
| `requirements` | Stable IDs, artifact/object targets, check IDs, manual review status |
| `protected` | Requested domains/products/counts, checked without auto-repair |

The MVP supports ordered composite PK/FK tuples for structural checks and DDL
rendering. Types must match by position; do not flatten a composite key into one
column. Actual runtime support must be verified separately.

## Metric design

Keep metric definitions in the analytical layer; do not distort normalized
products to make a report convenient. Before specifying a metric, record:

- **Purpose and owner:** the business question, accountable steward, audience,
  and decisions the metric supports.
- **Grain:** what one input row means and what one output group means. State
  whether counts refer to events, entities, versions, or distinct business
  identities; these are not interchangeable.
- **Dimensions:** each grouping field, its owning product, conformed meaning,
  time zone/calendar, and hierarchy or slowly changing behavior where relevant.
- **Measures:** source facts, formula, unit, precision, sign convention, and
  whether each measure is additive, semi-additive, or non-additive. Ratios and
  averages should normally be derived from their components at query time, not
  summed or averaged as if they were additive.
- **Time:** event/effective/recorded date choice, interval boundaries, late
  arriving changes, and the as-of policy.
- **Missingness:** the difference between no row, NULL, zero, and not applicable;
  document zero-denominator and empty-group behavior.
- **Scope and lineage:** source attributes, filters, exclusions, and known
  limitations. Keep currency, unit, status, and version scope visible in the
  result or explicitly constrain the metric.

### Joining multiple sources

Multiple sources are valid when they represent a deliberate business
relationship, not merely similarly named keys. For every join, document the
source grains, exact key/role, expected cardinality, optionality, temporal
alignment, and whether the join can multiply fact rows. Confirm that all
measures remain at a compatible grain. If sources have different grains,
pre-aggregate or use a conformed dimension only when the business semantics
support it; never hide fan-out with `DISTINCT`.

For a multi-source metric, include a join map and a fan-out/uniqueness
verification plan in the design even if the target metric technology cannot
express that plan directly. The bounded `metric_views` field in contract 1.0.0
and its static validator describe single-source projections only. Do not encode
a multi-source design as a single-source view or treat unsupported contract
shape as proof that the metric is invalid. Record the design as a proposal and
hand platform syntax, capability checks, and runtime validation to the relevant
specialist. When targeting Databricks metric views, use the optional
`databricks-metric-views` skill or authoritative documentation rather than
guessing YAML/version support.

### Example review: header and line measures

Suppose a report needs submitted-claim billed/paid totals and service-line units
by service month and currency. `claim.header` is one row per submitted version;
`claim.line` is many rows per header. Joining raw headers to lines and summing
header amounts repeats each header total once per line. A defensible design first
aggregates line facts to one row per `header_id`, then joins that result to the
header. The proposal records the expected one-to-one post-aggregation join,
uses the header service-month policy, and groups money by currency. Before
approval, verify line uniqueness and that line currencies agree with the header;
if either is unproven, block combined totals or report the measures separately.
This example is a grain/join review, not a supported YAML artifact or an
assertion that the bundled static validator can validate multi-source metrics.

## Defaults and ordering

Use BIGINT surrogate keys unless there is a reason to use a different supported
key type. Declare business uniqueness separately; a surrogate does not prevent
duplicate business records. Never infer PK declarations from name suffixes.

Order columns PK, FKs, business fields, housekeeping, then history. This is a
readability convention, not a Databricks requirement. All PK columns are
non-nullable. Declared `monetary` values must use explicit DECIMAL precision/scale.
The configured `key_type` is a synthesis default, not a ban on a justified
composite business-key type. Do not assume
identity generation is appropriate for distributed/concurrent ingestion.

Use semantic names and preserve units. Contextualize generic names such as
`status`; avoid needless prefixes on already-specific terms. Separate allowed
values from STRING format patterns. Type inference from names is only a proposal
until reviewed; BOOLEAN flags do not carry regexes.

## Unknowns

Missing stewardship, jurisdiction-specific standards, temporal grain, or source
identity guarantees are explicit design decisions. Record unknowns in the brief
and block claims that depend on them. A glossary or classification string is not
a guarantee of legal compliance.
