# Model evolution

Modification notice: source versioning/mutation principles are adapted; notebook
version aliases and automatic deploy/promote actions are excluded.

1. Preserve the input snapshot and its hash/version.
2. Classify requested changes: add, rename, relocate, merge, remove, resize, or
   change type/grain/temporal behavior.
3. Record requirement IDs and a new model version. Skill version and contract
   version are independent.
4. Compute dependency and consumer impact: FK endpoints, names, metrics, tags,
   DBML/docs, source mappings, samples if any, and live data migration needs.
5. Propose changes with explicit protected-name/count checks and rollback path.
6. Apply only approved changes to a new artifact set and verify all affected
   representations.

## Review proposal

Use the [model-change proposal template](../templates/model-change-proposal.json)
to produce a portable review artifact before implementation. The worked
[coverage rule change](../examples/model-evolution/README.md) illustrates the
expected level of impact analysis.

For each changed object, classify the change and record its rationale, old/new
meaning, and evidence. Trace impact through product grains, keys, FK endpoints,
dependent products, metric definitions, source mappings, tags, documentation,
and downstream consumers. Explicitly assess data preservation/backfill,
nullability, uniqueness, temporal history, compatibility, and rollback. Separate
requested facts, assumptions, unresolved decisions, proposed actions, approved
actions, and verified outcomes.

Renames and removals are not inferable from name similarity or absence. Mark a
change blocked/manual review when identity, mapping, data-preservation, or
compatibility is unresolved. A proposal is neither approval nor executable DDL.
The model owner and implementation specialist choose a target-specific migration
approach after review; workspace execution and data migration remain outside this
advisor skill.

Shrink is a scope decision, not an automatic ratio to source size. Preserve
required process coverage and complete surviving entities. Enlarge retains
existing protected identities unless the user approves a redesign. Do not remove
associations simply to hit a global percentage.

A surrogate PK, natural key, FK, and event snapshot serve different purposes;
changing one can require data migration. `CREATE OR REPLACE TABLE` is not a safe
generic repair. `IF NOT EXISTS` protects against replacement but does not reconcile
schema drift. Existing workspace changes require their own authorization and
physical/data verification.

Deliver an adaptation log and requirement traceability alongside the new model.
Report `blocked` if a cycle policy and a protected relationship conflict, rather
than breaking the relationship to manufacture a pass.
