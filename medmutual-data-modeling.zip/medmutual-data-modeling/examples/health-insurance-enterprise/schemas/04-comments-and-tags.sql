-- Re-authored conceptual artifact; see the suite README for provenance and boundaries.
-- NOT EXECUTED. Substitute reviewed __CATALOG__ offline before authorized use.


ALTER SCHEMA `__CATALOG__`.`member` SET TAGS ('dbx_division' = 'business');

ALTER TABLE `__CATALOG__`.`member`.`identity` SET TAGS ('dbx_data_type' = 'master_data', 'dbx_steward' = 'example_data_stewards', 'dbx_subdomain' = 'person_identity');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `identity_id` SET TAGS ('dbx_business_glossary_term' = 'Identity Identifier', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `source_member_number` SET TAGS ('dbx_business_glossary_term' = 'Source Member Number', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `given_name` SET TAGS ('dbx_business_glossary_term' = 'Given Name', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `family_name` SET TAGS ('dbx_business_glossary_term' = 'Family Name', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `date_of_birth` SET TAGS ('dbx_business_glossary_term' = 'Date Of Birth', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `identity_status` SET TAGS ('dbx_business_glossary_term' = 'Identity Status', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `middle_name` SET TAGS ('dbx_business_glossary_term' = 'Middle Name', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `name_suffix` SET TAGS ('dbx_business_glossary_term' = 'Name Suffix', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `preferred_name` SET TAGS ('dbx_business_glossary_term' = 'Preferred Name', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `identity_type_code` SET TAGS ('dbx_business_glossary_term' = 'Identity Type Code', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `identity_status_reason` SET TAGS ('dbx_business_glossary_term' = 'Identity Status Reason', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `identity_status_at` SET TAGS ('dbx_business_glossary_term' = 'Identity Status At', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `effective_from` SET TAGS ('dbx_business_glossary_term' = 'Effective From', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `effective_to` SET TAGS ('dbx_business_glossary_term' = 'Effective To', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `preferred_language_code` SET TAGS ('dbx_business_glossary_term' = 'Preferred Language Code', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `email_address` SET TAGS ('dbx_business_glossary_term' = 'Email Address', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `email_verified_at` SET TAGS ('dbx_business_glossary_term' = 'Email Verified At', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `phone_number` SET TAGS ('dbx_business_glossary_term' = 'Phone Number', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `phone_verified_at` SET TAGS ('dbx_business_glossary_term' = 'Phone Verified At', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `contact_preference_code` SET TAGS ('dbx_business_glossary_term' = 'Contact Preference Code', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `contact_consent_status` SET TAGS ('dbx_business_glossary_term' = 'Contact Consent Status', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `contact_consent_at` SET TAGS ('dbx_business_glossary_term' = 'Contact Consent At', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `record_version` SET TAGS ('dbx_business_glossary_term' = 'Record Version', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `is_deceased` SET TAGS ('dbx_business_glossary_term' = 'Is Deceased', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `deceased_date` SET TAGS ('dbx_business_glossary_term' = 'Deceased Date', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `created_at` SET TAGS ('dbx_business_glossary_term' = 'Created At', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `created_by` SET TAGS ('dbx_business_glossary_term' = 'Created By', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `updated_at` SET TAGS ('dbx_business_glossary_term' = 'Updated At', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`member`.`identity` ALTER COLUMN `updated_by` SET TAGS ('dbx_business_glossary_term' = 'Updated By', 'dbx_classification' = 'internal');

ALTER SCHEMA `__CATALOG__`.`plan` SET TAGS ('dbx_division' = 'business');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` SET TAGS ('dbx_data_type' = 'master_data', 'dbx_steward' = 'example_data_stewards', 'dbx_subdomain' = 'plan_design');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `health_plan_id` SET TAGS ('dbx_business_glossary_term' = 'Health Plan Identifier', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `plan_code` SET TAGS ('dbx_business_glossary_term' = 'Plan Code', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `design_version` SET TAGS ('dbx_business_glossary_term' = 'Design Version', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `plan_name` SET TAGS ('dbx_business_glossary_term' = 'Plan Name', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `effective_from` SET TAGS ('dbx_business_glossary_term' = 'Effective From', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `effective_to` SET TAGS ('dbx_business_glossary_term' = 'Effective To', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `currency_code` SET TAGS ('dbx_business_glossary_term' = 'Currency Code', 'dbx_classification' = 'internal', 'dbx_standard_references' = 'ISO 4217 currency codes');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `deductible_amount` SET TAGS ('dbx_business_glossary_term' = 'Deductible Amount', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `plan_type_code` SET TAGS ('dbx_business_glossary_term' = 'Plan Type Code', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `market_segment_code` SET TAGS ('dbx_business_glossary_term' = 'Market Segment Code', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `funding_arrangement_code` SET TAGS ('dbx_business_glossary_term' = 'Funding Arrangement Code', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `plan_status` SET TAGS ('dbx_business_glossary_term' = 'Plan Status', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `plan_status_reason` SET TAGS ('dbx_business_glossary_term' = 'Plan Status Reason', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `status_changed_at` SET TAGS ('dbx_business_glossary_term' = 'Status Changed At', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `renewal_policy_code` SET TAGS ('dbx_business_glossary_term' = 'Renewal Policy Code', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `enrollment_open_date` SET TAGS ('dbx_business_glossary_term' = 'Enrollment Open Date', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `enrollment_close_date` SET TAGS ('dbx_business_glossary_term' = 'Enrollment Close Date', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `monthly_premium_amount` SET TAGS ('dbx_business_glossary_term' = 'Monthly Premium Amount', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `premium_frequency_code` SET TAGS ('dbx_business_glossary_term' = 'Premium Frequency Code', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `individual_deductible_amount` SET TAGS ('dbx_business_glossary_term' = 'Individual Deductible Amount', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `family_deductible_amount` SET TAGS ('dbx_business_glossary_term' = 'Family Deductible Amount', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `individual_out_of_pocket_maximum` SET TAGS ('dbx_business_glossary_term' = 'Individual Out Of Pocket Maximum', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `family_out_of_pocket_maximum` SET TAGS ('dbx_business_glossary_term' = 'Family Out Of Pocket Maximum', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `primary_care_copayment_amount` SET TAGS ('dbx_business_glossary_term' = 'Primary Care Copayment Amount', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `specialist_copayment_amount` SET TAGS ('dbx_business_glossary_term' = 'Specialist Copayment Amount', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `emergency_copayment_amount` SET TAGS ('dbx_business_glossary_term' = 'Emergency Copayment Amount', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `coinsurance_rate` SET TAGS ('dbx_business_glossary_term' = 'Coinsurance Rate', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `out_of_network_coinsurance_rate` SET TAGS ('dbx_business_glossary_term' = 'Out Of Network Coinsurance Rate', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `prescription_coverage_flag` SET TAGS ('dbx_business_glossary_term' = 'Prescription Coverage Flag', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `telehealth_coverage_flag` SET TAGS ('dbx_business_glossary_term' = 'Telehealth Coverage Flag', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `plan_document_reference` SET TAGS ('dbx_business_glossary_term' = 'Plan Document Reference', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `record_version` SET TAGS ('dbx_business_glossary_term' = 'Record Version', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`plan`.`health_plan` ALTER COLUMN `updated_at` SET TAGS ('dbx_business_glossary_term' = 'Updated At', 'dbx_classification' = 'internal');

ALTER SCHEMA `__CATALOG__`.`enrollment` SET TAGS ('dbx_division' = 'operations');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` SET TAGS ('dbx_data_type' = 'transactional_data', 'dbx_steward' = 'example_data_stewards', 'dbx_subdomain' = 'coverage_management');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `coverage_id` SET TAGS ('dbx_business_glossary_term' = 'Coverage Identifier', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `identity_id` SET TAGS ('dbx_business_glossary_term' = 'Identity Identifier', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `health_plan_id` SET TAGS ('dbx_business_glossary_term' = 'Health Plan Identifier', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `coverage_from` SET TAGS ('dbx_business_glossary_term' = 'Coverage From', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `coverage_to` SET TAGS ('dbx_business_glossary_term' = 'Coverage To', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `coverage_status` SET TAGS ('dbx_business_glossary_term' = 'Coverage Status', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `elected_at` SET TAGS ('dbx_business_glossary_term' = 'Elected At', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `enrollment_request_number` SET TAGS ('dbx_business_glossary_term' = 'Enrollment Request Number', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `election_type_code` SET TAGS ('dbx_business_glossary_term' = 'Election Type Code', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `coverage_source_code` SET TAGS ('dbx_business_glossary_term' = 'Coverage Source Code', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `coverage_effective_reason` SET TAGS ('dbx_business_glossary_term' = 'Coverage Effective Reason', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `coverage_termination_reason` SET TAGS ('dbx_business_glossary_term' = 'Coverage Termination Reason', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `subscriber_relationship_code` SET TAGS ('dbx_business_glossary_term' = 'Subscriber Relationship Code', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `coverage_tier_code` SET TAGS ('dbx_business_glossary_term' = 'Coverage Tier Code', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `approved_at` SET TAGS ('dbx_business_glossary_term' = 'Approved At', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `terminated_at` SET TAGS ('dbx_business_glossary_term' = 'Terminated At', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `is_retroactive` SET TAGS ('dbx_business_glossary_term' = 'Is Retroactive', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `is_continuation` SET TAGS ('dbx_business_glossary_term' = 'Is Continuation', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `continuation_end_date` SET TAGS ('dbx_business_glossary_term' = 'Continuation End Date', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `coverage_duration_days` SET TAGS ('dbx_business_glossary_term' = 'Coverage Duration Days', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `eligibility_checked_at` SET TAGS ('dbx_business_glossary_term' = 'Eligibility Checked At', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `eligibility_result_code` SET TAGS ('dbx_business_glossary_term' = 'Eligibility Result Code', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `record_version` SET TAGS ('dbx_business_glossary_term' = 'Record Version', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `created_at` SET TAGS ('dbx_business_glossary_term' = 'Created At', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`enrollment`.`coverage` ALTER COLUMN `updated_at` SET TAGS ('dbx_business_glossary_term' = 'Updated At', 'dbx_classification' = 'internal');

ALTER SCHEMA `__CATALOG__`.`provider` SET TAGS ('dbx_division' = 'operations');

ALTER TABLE `__CATALOG__`.`provider`.`provider` SET TAGS ('dbx_data_type' = 'master_data', 'dbx_steward' = 'example_data_stewards', 'dbx_subdomain' = 'provider_identity');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `provider_id` SET TAGS ('dbx_business_glossary_term' = 'Provider Identifier', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `provider_number` SET TAGS ('dbx_business_glossary_term' = 'Provider Number', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `provider_name` SET TAGS ('dbx_business_glossary_term' = 'Provider Name', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `provider_kind` SET TAGS ('dbx_business_glossary_term' = 'Provider Kind', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `provider_status` SET TAGS ('dbx_business_glossary_term' = 'Provider Status', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `legal_entity_name` SET TAGS ('dbx_business_glossary_term' = 'Legal Entity Name', 'dbx_classification' = 'confidential');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `doing_business_as_name` SET TAGS ('dbx_business_glossary_term' = 'Doing Business As Name', 'dbx_classification' = 'confidential');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `provider_identifier_type` SET TAGS ('dbx_business_glossary_term' = 'Provider Identifier Type', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `organization_type_code` SET TAGS ('dbx_business_glossary_term' = 'Organization Type Code', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `primary_specialty_code` SET TAGS ('dbx_business_glossary_term' = 'Primary Specialty Code', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `secondary_specialty_code` SET TAGS ('dbx_business_glossary_term' = 'Secondary Specialty Code', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `license_number` SET TAGS ('dbx_business_glossary_term' = 'License Number', 'dbx_classification' = 'confidential');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `license_jurisdiction_code` SET TAGS ('dbx_business_glossary_term' = 'License Jurisdiction Code', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `license_expiration_date` SET TAGS ('dbx_business_glossary_term' = 'License Expiration Date', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `credentialing_status` SET TAGS ('dbx_business_glossary_term' = 'Credentialing Status', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `credentialed_at` SET TAGS ('dbx_business_glossary_term' = 'Credentialed At', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `credential_expiration_date` SET TAGS ('dbx_business_glossary_term' = 'Credential Expiration Date', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `recredential_due_date` SET TAGS ('dbx_business_glossary_term' = 'Recredential Due Date', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `contracting_status` SET TAGS ('dbx_business_glossary_term' = 'Contracting Status', 'dbx_classification' = 'confidential');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `contract_start_date` SET TAGS ('dbx_business_glossary_term' = 'Contract Start Date', 'dbx_classification' = 'confidential');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `contract_end_date` SET TAGS ('dbx_business_glossary_term' = 'Contract End Date', 'dbx_classification' = 'confidential');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `accepting_new_patients_flag` SET TAGS ('dbx_business_glossary_term' = 'Accepting New Patients Flag', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `directory_display_name` SET TAGS ('dbx_business_glossary_term' = 'Directory Display Name', 'dbx_classification' = 'confidential');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `directory_last_verified_at` SET TAGS ('dbx_business_glossary_term' = 'Directory Last Verified At', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `primary_contact_email` SET TAGS ('dbx_business_glossary_term' = 'Primary Contact Email', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `primary_contact_phone` SET TAGS ('dbx_business_glossary_term' = 'Primary Contact Phone', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `record_version` SET TAGS ('dbx_business_glossary_term' = 'Record Version', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `created_at` SET TAGS ('dbx_business_glossary_term' = 'Created At', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`provider`.`provider` ALTER COLUMN `updated_at` SET TAGS ('dbx_business_glossary_term' = 'Updated At', 'dbx_classification' = 'internal');

ALTER SCHEMA `__CATALOG__`.`network` SET TAGS ('dbx_division' = 'operations');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` SET TAGS ('dbx_data_type' = 'master_data', 'dbx_steward' = 'example_data_stewards', 'dbx_subdomain' = 'network_participation');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `provider_network_id` SET TAGS ('dbx_business_glossary_term' = 'Provider Network Identifier', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `network_code` SET TAGS ('dbx_business_glossary_term' = 'Network Code', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `network_name` SET TAGS ('dbx_business_glossary_term' = 'Network Name', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `network_status` SET TAGS ('dbx_business_glossary_term' = 'Network Status', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `network_type_code` SET TAGS ('dbx_business_glossary_term' = 'Network Type Code', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `network_status_reason` SET TAGS ('dbx_business_glossary_term' = 'Network Status Reason', 'dbx_classification' = 'confidential');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `effective_from` SET TAGS ('dbx_business_glossary_term' = 'Effective From', 'dbx_classification' = 'confidential');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `effective_to` SET TAGS ('dbx_business_glossary_term' = 'Effective To', 'dbx_classification' = 'confidential');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `market_segment_code` SET TAGS ('dbx_business_glossary_term' = 'Market Segment Code', 'dbx_classification' = 'confidential');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `region_code` SET TAGS ('dbx_business_glossary_term' = 'Region Code', 'dbx_classification' = 'confidential');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `access_model_code` SET TAGS ('dbx_business_glossary_term' = 'Access Model Code', 'dbx_classification' = 'confidential');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `product_line_code` SET TAGS ('dbx_business_glossary_term' = 'Product Line Code', 'dbx_classification' = 'confidential');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `contract_reference` SET TAGS ('dbx_business_glossary_term' = 'Contract Reference', 'dbx_classification' = 'confidential');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `contract_version` SET TAGS ('dbx_business_glossary_term' = 'Contract Version', 'dbx_classification' = 'confidential');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `contracting_entity_name` SET TAGS ('dbx_business_glossary_term' = 'Contracting Entity Name', 'dbx_classification' = 'confidential');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `directory_visibility_flag` SET TAGS ('dbx_business_glossary_term' = 'Directory Visibility Flag', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `directory_last_verified_at` SET TAGS ('dbx_business_glossary_term' = 'Directory Last Verified At', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `member_service_phone` SET TAGS ('dbx_business_glossary_term' = 'Member Service Phone', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `provider_relations_email` SET TAGS ('dbx_business_glossary_term' = 'Provider Relations Email', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `provider_relations_phone` SET TAGS ('dbx_business_glossary_term' = 'Provider Relations Phone', 'dbx_classification' = 'restricted', 'sensitivity' = 'personal');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `claim_submission_channel_code` SET TAGS ('dbx_business_glossary_term' = 'Claim Submission Channel Code', 'dbx_classification' = 'confidential');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `reimbursement_method_code` SET TAGS ('dbx_business_glossary_term' = 'Reimbursement Method Code', 'dbx_classification' = 'confidential');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `roster_effective_at` SET TAGS ('dbx_business_glossary_term' = 'Roster Effective At', 'dbx_classification' = 'confidential');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `roster_updated_at` SET TAGS ('dbx_business_glossary_term' = 'Roster Updated At', 'dbx_classification' = 'confidential');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `record_version` SET TAGS ('dbx_business_glossary_term' = 'Record Version', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `created_at` SET TAGS ('dbx_business_glossary_term' = 'Created At', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`network`.`provider_network` ALTER COLUMN `updated_at` SET TAGS ('dbx_business_glossary_term' = 'Updated At', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`network`.`participation` SET TAGS ('dbx_data_type' = 'association_data', 'dbx_steward' = 'example_data_stewards', 'dbx_subdomain' = 'network_participation');

ALTER TABLE `__CATALOG__`.`network`.`participation` ALTER COLUMN `participation_id` SET TAGS ('dbx_business_glossary_term' = 'Participation Identifier', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`network`.`participation` ALTER COLUMN `provider_id` SET TAGS ('dbx_business_glossary_term' = 'Provider Identifier', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`network`.`participation` ALTER COLUMN `provider_network_id` SET TAGS ('dbx_business_glossary_term' = 'Provider Network Identifier', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`network`.`participation` ALTER COLUMN `participation_from` SET TAGS ('dbx_business_glossary_term' = 'Participation From', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`network`.`participation` ALTER COLUMN `participation_to` SET TAGS ('dbx_business_glossary_term' = 'Participation To', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`network`.`participation` ALTER COLUMN `participation_status` SET TAGS ('dbx_business_glossary_term' = 'Participation Status', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`network`.`participation` ALTER COLUMN `created_at` SET TAGS ('dbx_business_glossary_term' = 'Created At', 'dbx_classification' = 'internal');

ALTER SCHEMA `__CATALOG__`.`claim` SET TAGS ('dbx_division' = 'operations');

ALTER TABLE `__CATALOG__`.`claim`.`claim_status` SET TAGS ('dbx_data_type' = 'reference_data', 'dbx_steward' = 'example_data_stewards', 'dbx_subdomain' = 'claim_processing');

ALTER TABLE `__CATALOG__`.`claim`.`claim_status` ALTER COLUMN `claim_status_id` SET TAGS ('dbx_business_glossary_term' = 'Claim Status Identifier', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`claim`.`claim_status` ALTER COLUMN `status_code` SET TAGS ('dbx_business_glossary_term' = 'Status Code', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`claim`.`claim_status` ALTER COLUMN `status_label` SET TAGS ('dbx_business_glossary_term' = 'Status Label', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`claim`.`claim_status` ALTER COLUMN `is_terminal` SET TAGS ('dbx_business_glossary_term' = 'Is Terminal', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`claim`.`header` SET TAGS ('dbx_data_type' = 'transactional_data', 'dbx_steward' = 'example_data_stewards', 'dbx_subdomain' = 'claim_processing');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `header_id` SET TAGS ('dbx_business_glossary_term' = 'Header Identifier', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `coverage_id` SET TAGS ('dbx_business_glossary_term' = 'Coverage Identifier', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `billing_provider_id` SET TAGS ('dbx_business_glossary_term' = 'Billing Provider Identifier', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `rendering_provider_id` SET TAGS ('dbx_business_glossary_term' = 'Rendering Provider Identifier', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `claim_status_id` SET TAGS ('dbx_business_glossary_term' = 'Claim Status Identifier', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `claim_number` SET TAGS ('dbx_business_glossary_term' = 'Claim Number', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `submission_version` SET TAGS ('dbx_business_glossary_term' = 'Submission Version', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `received_at` SET TAGS ('dbx_business_glossary_term' = 'Received At', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `service_date` SET TAGS ('dbx_business_glossary_term' = 'Service Date', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `currency_code` SET TAGS ('dbx_business_glossary_term' = 'Currency Code', 'dbx_classification' = 'restricted', 'dbx_standard_references' = 'ISO 4217 currency codes', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `billed_amount` SET TAGS ('dbx_business_glossary_term' = 'Billed Amount', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `allowed_amount` SET TAGS ('dbx_business_glossary_term' = 'Allowed Amount', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `paid_amount` SET TAGS ('dbx_business_glossary_term' = 'Paid Amount', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `original_claim_number` SET TAGS ('dbx_business_glossary_term' = 'Original Claim Number', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `replacement_reason_code` SET TAGS ('dbx_business_glossary_term' = 'Replacement Reason Code', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `claim_form_type_code` SET TAGS ('dbx_business_glossary_term' = 'Claim Form Type Code', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `claim_frequency_code` SET TAGS ('dbx_business_glossary_term' = 'Claim Frequency Code', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `submission_channel_code` SET TAGS ('dbx_business_glossary_term' = 'Submission Channel Code', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `accepted_at` SET TAGS ('dbx_business_glossary_term' = 'Accepted At', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `processing_started_at` SET TAGS ('dbx_business_glossary_term' = 'Processing Started At', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `processing_completed_at` SET TAGS ('dbx_business_glossary_term' = 'Processing Completed At', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `adjudication_due_date` SET TAGS ('dbx_business_glossary_term' = 'Adjudication Due Date', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `service_period_end_date` SET TAGS ('dbx_business_glossary_term' = 'Service Period End Date', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `billed_line_count` SET TAGS ('dbx_business_glossary_term' = 'Billed Line Count', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `total_denied_amount` SET TAGS ('dbx_business_glossary_term' = 'Total Denied Amount', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `member_responsibility_amount` SET TAGS ('dbx_business_glossary_term' = 'Member Responsibility Amount', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `deductible_amount` SET TAGS ('dbx_business_glossary_term' = 'Deductible Amount', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `copayment_amount` SET TAGS ('dbx_business_glossary_term' = 'Copayment Amount', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `coinsurance_amount` SET TAGS ('dbx_business_glossary_term' = 'Coinsurance Amount', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `is_replacement_claim` SET TAGS ('dbx_business_glossary_term' = 'Is Replacement Claim', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `is_coordination_of_benefits` SET TAGS ('dbx_business_glossary_term' = 'Is Coordination Of Benefits', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `record_version` SET TAGS ('dbx_business_glossary_term' = 'Record Version', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `paid_at` SET TAGS ('dbx_business_glossary_term' = 'Paid At', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`header` ALTER COLUMN `updated_at` SET TAGS ('dbx_business_glossary_term' = 'Updated At', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`claim`.`line` SET TAGS ('dbx_data_type' = 'transactional_data', 'dbx_steward' = 'example_data_stewards', 'dbx_subdomain' = 'claim_processing');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `line_id` SET TAGS ('dbx_business_glossary_term' = 'Line Identifier', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `header_id` SET TAGS ('dbx_business_glossary_term' = 'Header Identifier', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `line_number` SET TAGS ('dbx_business_glossary_term' = 'Line Number', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `service_code` SET TAGS ('dbx_business_glossary_term' = 'Service Code', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `service_date` SET TAGS ('dbx_business_glossary_term' = 'Service Date', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `service_quantity` SET TAGS ('dbx_business_glossary_term' = 'Service Quantity', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `unit_price_at_service` SET TAGS ('dbx_business_glossary_term' = 'Unit Price At Service', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `service_category_code` SET TAGS ('dbx_business_glossary_term' = 'Service Category Code', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `service_end_date` SET TAGS ('dbx_business_glossary_term' = 'Service End Date', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `place_of_service_code` SET TAGS ('dbx_business_glossary_term' = 'Place Of Service Code', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `line_charge_amount` SET TAGS ('dbx_business_glossary_term' = 'Line Charge Amount', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `line_allowed_amount` SET TAGS ('dbx_business_glossary_term' = 'Line Allowed Amount', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `line_paid_amount` SET TAGS ('dbx_business_glossary_term' = 'Line Paid Amount', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `line_denied_amount` SET TAGS ('dbx_business_glossary_term' = 'Line Denied Amount', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `member_responsibility_amount` SET TAGS ('dbx_business_glossary_term' = 'Member Responsibility Amount', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `deductible_amount` SET TAGS ('dbx_business_glossary_term' = 'Deductible Amount', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `copayment_amount` SET TAGS ('dbx_business_glossary_term' = 'Copayment Amount', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `coinsurance_amount` SET TAGS ('dbx_business_glossary_term' = 'Coinsurance Amount', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `currency_code` SET TAGS ('dbx_business_glossary_term' = 'Currency Code', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `units_allowed` SET TAGS ('dbx_business_glossary_term' = 'Units Allowed', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `units_denied` SET TAGS ('dbx_business_glossary_term' = 'Units Denied', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `line_status` SET TAGS ('dbx_business_glossary_term' = 'Line Status', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `line_status_at` SET TAGS ('dbx_business_glossary_term' = 'Line Status At', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `is_emergency_service` SET TAGS ('dbx_business_glossary_term' = 'Is Emergency Service', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `is_inpatient_service` SET TAGS ('dbx_business_glossary_term' = 'Is Inpatient Service', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `contract_rate_at_service` SET TAGS ('dbx_business_glossary_term' = 'Contract Rate At Service', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `source_line_reference` SET TAGS ('dbx_business_glossary_term' = 'Source Line Reference', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `created_at` SET TAGS ('dbx_business_glossary_term' = 'Created At', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`claim`.`line` ALTER COLUMN `updated_at` SET TAGS ('dbx_business_glossary_term' = 'Updated At', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` SET TAGS ('dbx_data_type' = 'transactional_data', 'dbx_steward' = 'example_data_stewards', 'dbx_subdomain' = 'claim_processing');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `adjudication_id` SET TAGS ('dbx_business_glossary_term' = 'Adjudication Identifier', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `header_id` SET TAGS ('dbx_business_glossary_term' = 'Header Identifier', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `decided_at` SET TAGS ('dbx_business_glossary_term' = 'Decided At', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `decision_outcome` SET TAGS ('dbx_business_glossary_term' = 'Decision Outcome', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `decision_reason` SET TAGS ('dbx_business_glossary_term' = 'Decision Reason', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `allowed_amount_at_decision` SET TAGS ('dbx_business_glossary_term' = 'Allowed Amount At Decision', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `decision_sequence_number` SET TAGS ('dbx_business_glossary_term' = 'Decision Sequence Number', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `decision_stage_code` SET TAGS ('dbx_business_glossary_term' = 'Decision Stage Code', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `decision_reason_category` SET TAGS ('dbx_business_glossary_term' = 'Decision Reason Category', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `decision_reason_detail` SET TAGS ('dbx_business_glossary_term' = 'Decision Reason Detail', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `decision_method_code` SET TAGS ('dbx_business_glossary_term' = 'Decision Method Code', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `review_requested_at` SET TAGS ('dbx_business_glossary_term' = 'Review Requested At', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `review_completed_at` SET TAGS ('dbx_business_glossary_term' = 'Review Completed At', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `payment_due_date` SET TAGS ('dbx_business_glossary_term' = 'Payment Due Date', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `service_period_start_date` SET TAGS ('dbx_business_glossary_term' = 'Service Period Start Date', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `service_period_end_date` SET TAGS ('dbx_business_glossary_term' = 'Service Period End Date', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `adjudication_currency_code` SET TAGS ('dbx_business_glossary_term' = 'Adjudication Currency Code', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `discount_amount` SET TAGS ('dbx_business_glossary_term' = 'Discount Amount', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `denied_amount` SET TAGS ('dbx_business_glossary_term' = 'Denied Amount', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `member_responsibility_amount` SET TAGS ('dbx_business_glossary_term' = 'Member Responsibility Amount', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `deductible_amount` SET TAGS ('dbx_business_glossary_term' = 'Deductible Amount', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `copayment_amount` SET TAGS ('dbx_business_glossary_term' = 'Copayment Amount', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `coinsurance_amount` SET TAGS ('dbx_business_glossary_term' = 'Coinsurance Amount', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `is_final_decision` SET TAGS ('dbx_business_glossary_term' = 'Is Final Decision', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `is_appealable` SET TAGS ('dbx_business_glossary_term' = 'Is Appealable', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `appeal_deadline` SET TAGS ('dbx_business_glossary_term' = 'Appeal Deadline', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `decision_version` SET TAGS ('dbx_business_glossary_term' = 'Decision Version', 'dbx_classification' = 'restricted', 'sensitivity' = 'health');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `created_at` SET TAGS ('dbx_business_glossary_term' = 'Created At', 'dbx_classification' = 'internal');

ALTER TABLE `__CATALOG__`.`claim`.`adjudication` ALTER COLUMN `updated_at` SET TAGS ('dbx_business_glossary_term' = 'Updated At', 'dbx_classification' = 'internal');
