-- Re-authored conceptual artifact; see the suite README for provenance and boundaries.
-- NOT EXECUTED. Substitute reviewed __CATALOG__ offline before authorized use.


CREATE CATALOG IF NOT EXISTS `__CATALOG__`;

CREATE SCHEMA IF NOT EXISTS `__CATALOG__`.`member` COMMENT 'Owns the member business records required for the bounded member enrollment, provider network, and claim lifecycle reference; product grains and stewardship remain explicit.';

CREATE SCHEMA IF NOT EXISTS `__CATALOG__`.`plan` COMMENT 'Owns the plan business records required for the bounded member enrollment, provider network, and claim lifecycle reference; product grains and stewardship remain explicit.';

CREATE SCHEMA IF NOT EXISTS `__CATALOG__`.`enrollment` COMMENT 'Owns the enrollment business records required for the bounded member enrollment, provider network, and claim lifecycle reference; product grains and stewardship remain explicit.';

CREATE SCHEMA IF NOT EXISTS `__CATALOG__`.`provider` COMMENT 'Owns the provider business records required for the bounded member enrollment, provider network, and claim lifecycle reference; product grains and stewardship remain explicit.';

CREATE SCHEMA IF NOT EXISTS `__CATALOG__`.`network` COMMENT 'Owns the network business records required for the bounded member enrollment, provider network, and claim lifecycle reference; product grains and stewardship remain explicit.';

CREATE SCHEMA IF NOT EXISTS `__CATALOG__`.`claim` COMMENT 'Owns the claim business records required for the bounded member enrollment, provider network, and claim lifecycle reference; product grains and stewardship remain explicit.';

CREATE SCHEMA IF NOT EXISTS `__CATALOG__`.`metrics`;
