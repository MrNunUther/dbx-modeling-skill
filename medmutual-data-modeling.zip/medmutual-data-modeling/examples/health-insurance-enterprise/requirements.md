# Enterprise-depth reference requirements

These are requirements for the conceptual reference suite, not universal insurer
requirements.

| ID | Requirement | Verification |
|---|---|---|
| REQ-01 | Retain the six named domains and ten named products while deepening the same bounded process. | Protected names/counts; review the scope gate |
| REQ-02 | Connect member/plan enrollment, provider/network participation, and claim intake through line and decision events. | PK/FK closure and manual process review |
| REQ-03 | Give master and transactional products substantive business fields at their declared grains; keep the small vocabulary and association unpadded. | Attribute metadata checks, depth profile, manual purpose review |
| REQ-04 | Keep event-time facts and distinct temporal semantics; do not imply that source-current attributes replace event snapshots. | Manual snapshot/temporal review |
| REQ-05 | Keep the claim financial projection at submitted-version grain and group monetary measures by currency. | Metric expression/source checks and manual grain review |
| REQ-06 | Keep canonical JSON and supported SQL/DBML/integrity artifacts in deterministic parity. | Renderer parity check |
| REQ-07 | State unverified business, sensitivity, physical, and data claims honestly. | Manual review; live checks remain `not_run` |

**Explicitly bounded out:** this reference does not add products to meet
per-domain count ratios. It does not model all insurer functions, source systems,
licensed code sets, production vocabularies, legal rules, or live data evidence.
