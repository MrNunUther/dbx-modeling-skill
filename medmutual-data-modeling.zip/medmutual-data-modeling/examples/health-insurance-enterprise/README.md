# Health-insurance enterprise-depth reference

This is a bounded, conceptual process reference for member enrollment, provider
network participation, and claim receipt through adjudication/payment reporting.
It is separately authored from the deliberately thin
[teaching suite](../health-insurance/README.md); it does not replace it.

## Scope gate

The six domains and ten product identities are retained from the teaching suite.
The model deepens the eight master/transactional products and leaves the small
claim-status vocabulary and relationship-owned participation product narrow
where their semantics warrant it. No products were added to meet a ratio.

| Domain | Products | Illustrative product depth |
|---|---|---|
| `member` | `identity` | 29 columns |
| `plan` | `health_plan` | 33 columns |
| `enrollment` | `coverage` | 25 columns |
| `provider` | `provider` | 29 columns |
| `network` | `provider_network`, `participation` | 27, 7 columns |
| `claim` | `claim_status`, `header`, `line`, `adjudication` | 4, 34, 29, 29 columns |

The figures describe this example only. They are not minimums for another
industry or a quota for a bounded user-requested model. If adapting it, first
confirm the requested process boundary and each product's grain. Add a product
only when a process or relationship has its own business identity/history;
leave unsupported domain facts as questions instead of inventing values.

## Process path and reading order

1. `member.identity` identifies a person independently of coverage.
2. `plan.health_plan` retains plan design versions; `enrollment.coverage` links
   the person to a plan for an interval.
3. `provider.provider`, `network.provider_network`, and
   `network.participation` separate provider identity, network identity, and
   time-bounded participation.
4. `claim.header` represents a submitted claim version that references coverage
   and billing/rendering provider roles.
5. `claim.line` records service-level occurrences and financial facts;
   `claim.adjudication` retains decision events rather than overwriting the
   header.
6. `metrics.claim_financials` is an analytical projection over claim submissions,
   grouped by service month and currency.

Read the [requirements](requirements.md) and
[traceability](traceability.csv), then the canonical
[model](model.json). Derivative SQL, DBML, integrity queries, and the
[static report](validation/static-report.json) are generated from that model.
The one-source metric example avoids join fan-out; it does not demonstrate every
metric technology capability.

## Assumptions and non-goals

- This is a re-authored conceptual reference, not a source-system specification,
  certified insurer model, or compliance assessment.
- Identifiers and vocabularies are illustrative. No clinical code set,
  production status vocabulary, source guarantees, sample person data, or legal
  rules are included.
- Personal/health sensitivity labels are conservative example annotations and
  still require contextual policy review.
- Coverage interval boundaries, overlapping coverage, eligibility, claim
  completeness, amount reconciliation, payment timing, event ordering, and
  source identity are design/data questions—not facts proven by this model.
- Provider participation does not imply a plan-network contract. Diagnosis,
  authorization, remittance, households, address/contact history, and complete
  provider locations are outside this bounded process.
- SQL is illustrative and unexecuted. No Databricks connection, catalog check,
  row check, deployment, or mutation occurred.

## Regenerate and verify

From the skill root:

```bash
python scripts/render_example.py --root . --example health-insurance-enterprise --check
python scripts/validate_skill.py --root . --example health-insurance-enterprise
python scripts/shape_profile.py advise examples/health-insurance-enterprise/model.json --envelope templates/shape-envelope.json
python scripts/shape_profile.py check examples/health-insurance-enterprise/model.json --envelope templates/shape-envelope.json --scope mvm --format text
```

Use `--write` only after an approved canonical-model edit. Refresh the static
report and traceability statuses with
`python scripts/validate_skill.py --root . --example health-insurance-enterprise --write-report`.
The local static report does not establish physical/catalog or data validity;
those remain `not_run`.
The report verifies five static requirements and retains two manual requirements
as unverified.
Shape advisories are review prompts, not objectives to score-conform a bounded
example. The current profile reports product conformance `1.0`, depth fit
`0.85`, shape score `47.2`, composite `69.8`, and no structural defects. The
lower topology/composite scores reflect one product per domain on median and the
deliberately bounded 10-product scope; these scores are not a readiness grade.
The advised root masters have inbound use but no justified outbound dependency;
the status vocabulary is intentionally narrow; temporal lifecycle fields,
multiple amounts at distinct grains, and sensitive health/contact attributes
need manual review rather than automatic trimming. The claim header references
the lifecycle lookup by FK; the shape heuristic does not recognize that as an
inline status. No fields or products are added solely to satisfy a band.
