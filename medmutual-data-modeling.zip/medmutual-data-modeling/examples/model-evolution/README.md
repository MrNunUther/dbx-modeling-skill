# Model-evolution proposal example

This is a review artifact, not an executable migration script. It illustrates
how to keep an uncertain change explicit rather than inferring a safe conversion
or generating DDL.

## Scenario

A coverage operations team asks to change `enrollment.coverage.coverage_from`
and `coverage_to` from `DATE` to `TIMESTAMP` so same-day eligibility changes can
be represented. The request establishes a need for finer time precision, but
does not establish the authoritative time zone, source precision, interval
boundary semantics, treatment of existing records, or whether related claim
service dates should also change. The proposal therefore records the question
and blocks implementation approval pending decisions.

## Review outcome

| Area | Review |
|---|---|
| Change classification | Type and temporal-semantics change |
| Direct objects | `enrollment.coverage.coverage_from`, `coverage_to` |
| Dependent behavior | Coverage interval validation and overlap checks; claim-to-coverage service-date eligibility checks |
| Data preservation | Converting midnight dates to timestamps is only one possible mapping; source time and zone cannot be reconstructed from a date |
| Compatibility | Downstream consumers may assume day-grain dates; source mappings and period comparisons need review |
| Unresolved decisions | Authoritative time zone, source precision, inclusive/exclusive end, historical backfill rule, and downstream contract |
| Decision | `proposed`; approval not requested until semantics and affected consumers are resolved |
| Verification | Design review first; offline static checks after an approved model update; physical/data checks remain `not_run` until separately authorized |

The proposal does not assert that the change is approved, data-safe, or executable.
The owner may decide to retain `DATE`, add a separately named local-time field,
or revise the temporal model after answering the unresolved questions. Those are
design alternatives, not automatic repairs.

## Reuse

Start from [`model-change-proposal.json`](../../templates/model-change-proposal.json).
Record stable before/after model versions, requirements, evidence, object/dependency
impact, data-preservation concerns, unresolved decisions, approval state, and a
verification plan. Keep implementation and verification statuses distinct.
