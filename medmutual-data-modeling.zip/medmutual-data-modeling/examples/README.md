# Curated examples

Modification notice: examples are independently re-authored conceptual teaching
slices based on the inventoried ECM artifacts, not certified upstream models.

Start with the [health-insurance teaching suite](health-insurance/README.md) for
the shortest artifact walkthrough, or compare it with the separate
[health-insurance enterprise-depth reference](health-insurance-enterprise/README.md)
for a deeper multi-domain process. Read only the pattern relevant to your task;
do not import industry nouns into other models. The same
ownership/grain/key/metadata/evidence contracts apply to procurement,
manufacturing, service operations, and other domains.

No real person records, clinical code lists, licensed service-code descriptions,
source workbooks, lineage dumps, or synthetic-data engine are included.

For steering a poorly constructed table toward a common form, see the
[anti-pattern remodel](anti-patterns/README.md). The small
[health-insurance slice](health-insurance/README.md) remains deliberately thin;
the [enterprise-depth example](enterprise-depth/README.md) and
[cross-domain suite](health-insurance-enterprise/README.md) illustrate default
product depth without prescribing universal product counts.
